from django.http import HttpResponse
from django.shortcuts import render

from .models import Products


def index(request):
    Products.objects.all()
    return render(request,'index.html',{'products': Products})


def new(request):
    return HttpResponse('new products')

